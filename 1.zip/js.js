// 表单验证与提交处理：符合作业HTML5+原生JS验证要求
// 等待DOM完全加载后执行代码，确保元素已渲染
document.addEventListener('DOMContentLoaded', function() {
    // 获取表单元素与提示信息容器
    const ticketForm = document.getElementById('ticketForm');
    const formMessage = document.getElementById('formMessage');

    // 检查当前页面是否存在报名表单
    if (ticketForm) {
        // 为表单添加提交事件监听
        ticketForm.addEventListener('submit', function(e) {
            // 阻止表单默认提交行为（页面刷新）
            e.preventDefault();

            // 获取表单所有输入值并去除首尾空格
            const fullName = document.getElementById('fullName').value.trim();
            const email = document.getElementById('email').value.trim();
            const match = document.getElementById('match').value;
            const tickets = document.getElementById('tickets').value;

            // 基础必填项验证
            if (!fullName || !email || !match || !tickets) {
                // 有必填项为空时，显示错误提示
                formMessage.textContent = 'Error: Please fill in all required fields.';
                formMessage.className = 'form-message error';
                // 终止函数执行，阻止提交
                return;
            }

            // 邮箱格式正则验证
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                // 邮箱格式无效时，显示错误提示
                formMessage.textContent = 'Error: Please enter a valid email address.';
                formMessage.className = 'form-message error';
                // 终止函数执行，阻止提交
                return;
            }

            // 所有验证通过，显示成功提示
            formMessage.textContent = 'Success! Your ticket registration has been submitted. We will contact you via email soon.';
            formMessage.className = 'form-message success';

            // 提交成功后重置表单
            ticketForm.reset();

            // 5秒后自动隐藏成功提示
            setTimeout(function() {
                formMessage.style.display = 'none';
            }, 5000);
        });
    }
});